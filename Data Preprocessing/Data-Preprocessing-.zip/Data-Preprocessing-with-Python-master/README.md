# Data Preprocessing


<ol>
  <li>Central Tendency and Dispersion measures</li>
  <li>Handling missing values in a dataset</li>
  <li>Noise Smoothing with Binning</li>
  <li>PCA</li>
  <li>Apriori Algorithm</li>
<ol>
  
## Datasets
<ol>
  <li>Insurance Dataset</li>
  <li>Groceries Dataset</li>
  <li>Iris Dataset</li>
<ol>
